// 1. Importar o express
const express = require('express');

// 2. Inicializar a aplicação
const app = express();

// 3. Configurar para que o Express entenda JSON no corpo (body) das requisições
app.use(express.json());

// 4. Definir a porta
const PORT = 3000;

// Exemplo de rota GET
app.get('/hello', (req, res) => {
    res.send('Olá, Mundo!');
});

// 5. Ligar o servidor
app.listen(PORT, () => {
    console.log(`Servidor a correr em http://localhost:${PORT}`);
});